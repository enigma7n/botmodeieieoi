const Discord = require(`discord.js`)
const { JsonDatabase, } = require(`wio.db`);
const perms = new JsonDatabase({ databasePath:`./json/perms.json` });
const db = new JsonDatabase({ databasePath:`./db/products.json` });
const mj = new JsonDatabase({ databasePath:`./configs/emojis.json` });
const config = new JsonDatabase({ databasePath:`./configs/config.json` });
const fs = require(`fs`)


module.exports = {
    name: `bot`, 
    run: async(client, message, args) => {
        const conta = args[0]
        const usuario = message.author.id
        if (usuario !== `${perms.get(`${usuario}_id`)}`) return message.reply(`${mj.get(`errado`)} | ops..parece que você não tem perm!!`)
       
      const chave = args[0];
      const row = new Discord.MessageActionRow()

        .addComponents(
          new Discord.MessageButton()
            .setCustomId(`nomebot`)
           .setEmoji(mj.get(`config`))
            .setLabel(`Nome`)
            .setStyle(`SECONDARY`)
        )
        .addComponents(
          new Discord.MessageButton()
            .setCustomId(`fotobot`)
           .setEmoji(mj.get(`config`))
            .setLabel(`Avatar`)
            .setStyle(`SECONDARY`)
        )
        .addComponents(
          new Discord.MessageButton()
            .setCustomId(`pctchave`)
           .setEmoji(mj.get(`config`))
            .setLabel(`Cor`)
            .setStyle(`SECONDARY`)
        )
        .addComponents(
          new Discord.MessageButton()
            .setCustomId(`minchave`)
           .setEmoji(mj.get(`config`))
            .setLabel(`Cargo acesso`)
            .setStyle(`SECONDARY`)
        );
       ;
     
        ;
        
        const msg = await message.reply({
          embeds: [
            new Discord.MessageEmbed()

              .setDescription(
                `
<:Atendente:1135729208992211005> **| Nome:** ${client.user.username}
<:User:1135729214872629409> **| Cor:** ${config.get(`cor`)}
<:Carteira:1128880854429597806> **| Cargo acesso:** <@&${config.get(`role`)}>`
              )
              .setThumbnail(client.user.displayAvatarURL())
              .setColor(`${config.get(`cor`)}`),
          ],
          components: [row],
        });
        const interação = msg.createMessageComponentCollector({ componentType: `BUTTON`, })
        interação.on(`collect`, async (interaction) => {
         if (message.author.id != interaction.user.id) {
          return;
         }
                
         if (interaction.customId === `delchave`) {
           msg.delete()
             msg.channel.send(`${mj.get(`correto`)}  | Excluido!`)
           db.delete(`${chave}`)
         }
         if (interaction.customId === `nomebot`) {
             interaction.deferUpdate();
             msg.channel.send(`${mj.get(`carregando`)} | Qual o nome do Bot`).then(msg => {
               const filter = m => m.author.id === interaction.user.id;
               const collector = msg.channel.createMessageCollector({ filter, max: 1 });
               collector.on(`collect`, message => {
                 message.delete()
                 msg.delete()
                 if (message.content.length > 32) {
                   console.log(
                     `${mj.get(`errado`)} A mensagem excede o limite de 32 caracteres.`
                   );
                 } 
                 client.user.setUsername(`${message.content}`);
                message.channel.send(`${mj.get(`correto`)}  | Alterado!`)
             })
           })
         }
          if (interaction.customId === `fotobot`) {
            interaction.deferUpdate();
            msg.channel.send(`${mj.get(`carregando`)} | Envie a foto do bot?`).then((msg) => {
              const filter = (m) => m.author.id === interaction.user.id;
              const collector = msg.channel.createMessageCollector({
                filter,
                max: 1,
              });
              collector.on(`collect`, async (message) => {
                try {
                  const attachment = message.attachments.first();
                  if (attachment && attachment.url) {
                    const newAvatarUrl = attachment.url;
                    await client.user.setAvatar(newAvatarUrl);
                    msg.edit(`${mj.get(`correto`)}  | Foto do bot alterada!`);
                  } else {
                    msg.edit(`${mj.get(`errado`)} | Nenhuma imagem anexada foi encontrada.`);
                  }
                } catch (error) {
                  console.error(error);
                  msg.edit(`${mj.get(`errado`)} | Ocorreu um erro ao definir a foto do bot.`);
                }
                message.delete();
              });
            });
          }

         if (interaction.customId === `tokendomp`) {
          interaction.deferUpdate();
          msg.channel.send(`${mj.get(`carregando`)} | Qual o token do MP ?`).then(msg => {
            const filter = m => m.author.id === interaction.user.id;
            const collector = msg.channel.createMessageCollector({ filter, max: 1 });
            collector.on(`collect`, message => {
              message.delete()
              db.set(`acesstoken`, `${message.content}`)
              msg.edit(`${mj.get(`correto`)}  | Token Alterado!`)
          })
        })
      }
         if (interaction.customId === `minchave`) {
             interaction.deferUpdate();
             msg.channel.send(`${mj.get(`carregando`)} | Qual o cargo de cliente? (mande o id)`).then(msg => {
               const filter = m => m.author.id === interaction.user.id;
               const collector = msg.channel.createMessageCollector({ filter, max: 1 });
               collector.on(`collect`, message => {
                 message.delete()
                 db.set(`cargo`, `${message.content.replace(`,`, `.`)}`)
                 msg.edit(`${mj.get(`correto`)}  | Alterado!`)
             })
           })
         }
         if (interaction.customId === 'pctchave') {
             interaction.deferUpdate();
             msg.channel.send(`${mj.get(`carregando`)} | Qual a cor da embed? (ex: #00ff00)`).then(msg => {
               const filter = m => m.author.id === interaction.user.id;
               const collector = msg.channel.createMessageCollector({ filter, max: 1 });
               collector.on(`collect`, message => {
                 message.delete()
                 db.set(`cor`, `${message.content}`)
                 msg.edit(`${mj.get(`correto`)}  | Alterado!`)
             })
           })
         }
         if (interaction.customId === 'relchave') {
           interaction.deferUpdate();
           const embed = new Discord.MessageEmbed()
           .setTitle(`Configurações gerais`)
           .setDescription(`
 **Nome do bot:** ***${db.get(`nomebot`)}***
 **Cargo cliente:** <@&${db.get(`cargo`)}>
 **Token do Mercado Pago:** || ${db.get(`acesstoken`)} ||
 **Cor embed:** ${db.get(`cor`)}`)
           msg.edit({ embeds: [embed] })
           message.channel.send(`${mj.get(`correto`)}  | Atualizado!`)
             }
           })
         }
       }