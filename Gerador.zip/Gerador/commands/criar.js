const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const perms = new JsonDatabase({ databasePath:"./json/perms.json" });
const db = new JsonDatabase({ databasePath:"./db/products.json" });
const mj = new JsonDatabase({ databasePath:"./configs/emojis.json" });
module.exports = {
    name: "criar",
    aliases: ["cria"],
    run: async(client, message, args) => {
const conta = args[0]
const usuario = message.author.id
/////ifs//////////
if (usuario !== `${perms.get(`${usuario}_id`)}`) return message.reply(`${mj.get("errado")} | ops..parece que você não tem perm!!`)
if (!conta) return message.reply(`${mj.get("errado")} | ops... parece que você esqueceu de colocar um id para esse serviço!!`)
if(conta === `${db.get(`${conta}.idserviçe`)}`) return message.reply(`${mj.get("errado")} | ops... parece que ja temos esse serviço!!`)
//////ifs/////////


//////db//////////
db.set(`${conta}.idserviçe`,`${conta}`)
db.set(`${conta}.nome`,`Não configurado`)
db.set(`${conta}.footer`,`Olá, espero que estejá gostando de nosso sistema.`)
db.set(`${conta}.banner`, `https://cdn.discordapp.com/attachments/1126231664968867991/1127093829821014016/Green_and_Modern_Green_Vibrant_Media_Contact_List_Docs_Banner.png`);
db.push(`${conta}.conta`, [`${conta}`])
const a = db.get(`${conta}.conta`);
const removed = a.splice(0, 1);
db.set(`${conta}.conta`, a);
//////db//////////
        message.reply(`${mj.get("cerreto")} | Novo serviço criado!!`)

    }
}