const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const perm = new JsonDatabase({ databasePath:"./json/perms.json" });
const db = new JsonDatabase({ databasePath:"./db/products.json" });
const mj = new JsonDatabase({ databasePath:"./configs/emojis.json" });
const config = require("../configs/config.json")
module.exports = {
    name: "perm", 
    run: async(client, message, args) => {
const perms = args[0]
const usuario = message.author.id
     if(usuario !== `${config.dono}`) return message.reply(`${mj.get("errado")} **Olá, apenas o rootz pode fazer isso.**`)


     message.reply(`${mj.get("correto")} **Usúario foi adicionado com sucesso em nosso banco de dados.**`)
    perm.set(`${perms}_id`, `${perms}`)
       }
     }
