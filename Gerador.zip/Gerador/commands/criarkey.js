const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const perm = new JsonDatabase({ databasePath:"./json/perms.json" });
const db = new JsonDatabase({ databasePath:"./db/products.json" });
const mj = new JsonDatabase({ databasePath:"./configs/emojis.json" });
const kew = new JsonDatabase({ databasePath:"./json/keys.json" });
const config = new JsonDatabase({ databasePath:"./configs/config.json" });
module.exports = {
    name: "criarkey", 
    run: async(client, message, args) => {
      const conta = args[0]
      const usuario = message.author.id
      /////ifs//////////
      if (usuario !== `${perm.get(`${usuario}_id`)}`) return message.reply(`${mj.get("errado")} | ops..parece que você não tem perm!!`)
      const sequence = generateRandomSequence();
      function generateRandomSequence() {
        const characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        const length = 30;
        let sequence = '';
      
        for (let i = 0; i < length; i++) {
          const randomIndex = Math.floor(Math.random() * characters.length);
          const randomCharacter = characters[randomIndex];
          sequence += randomCharacter;
        }
      
        return sequence;
      }
     message.reply(`${mj.get("correto")} **Olá, sua key foi gerada com sucesso e já esta em sua dm.**`)
     const embed = new Discord.MessageEmbed()
.setDescription(`${mj.get("correto")} **Olá, sua key foi gerada com sucesso.**\n \`${sequence}\``)
.setColor(config.get("cor"))
message.author.send({embeds: [embed]})
kew.set(`${sequence}.key`,`${sequence}`)
kew.set(`${sequence}.resgatado`,`false`)
       }
     }
