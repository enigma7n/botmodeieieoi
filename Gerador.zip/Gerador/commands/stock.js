const Discord = require("discord.js");
const { JsonDatabase } = require("wio.db");
const perm = new JsonDatabase({ databasePath: "./json/perms.json" });

const mj = new JsonDatabase({ databasePath: "./configs/emojis.json" });
const config = require("../configs/config.json");
const db = new JsonDatabase({ databasePath: "./db/products.json" });

module.exports = {
  name: "stock",
  run: async (client, message, args) => {
    try {
      const allProducts = db.get(""); // Get all products from the database

      if (Object.keys(allProducts).length === 0) {
        return message.reply("Ops... você não tem nenhum produto criado!");
      }

      const embed = new Discord.MessageEmbed()
        .setThumbnail(client.user.displayAvatarURL())
        .setDescription(`✨ | Atualmente temos os seguintes serviços:`)
        .setColor(config.cor);

      let totalProdutos = 0;

      for (const [idserviçe, produto] of Object.entries(allProducts)) {
        const { nome, conta } = produto;

        let formattedNames = "";

        if (Array.isArray(nome) && nome.length > 0) {
          formattedNames = nome.join(", ");
        } else if (typeof nome === "string" && nome.trim() !== "") {
          formattedNames = nome;
        }

        if (formattedNames !== "") {
          const quantidadeContas = Array.isArray(conta) ? conta.length : 0;

          embed.addField(
            `${mj.get("caixa")} | ${idserviçe}`,
            `${formattedNames} - (${quantidadeContas} contas)`
          );
          totalProdutos++;
        }
      }

      if (embed.fields.length === 0) {
        embed.addField("Nenhum produto disponível", "N/A");
      }

      embed.setFooter(`Total de produtos: ${totalProdutos}`);

      message.channel.send({ embeds: [embed] });
    } catch (error) {
      console.error("Error accessing the database:", error);
      // Handle the error here (e.g., send an error message to the channel)
    }
  },
};
