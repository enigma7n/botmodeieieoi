const Discord = require('discord.js');
const { JsonDatabase } = require('wio.db');
const perms = new JsonDatabase({ databasePath: './json/perms.json' });
const db = new JsonDatabase({ databasePath: './db/products.json' });
const mj = new JsonDatabase({ databasePath: './configs/emojis.json' });
const fs = require('fs');
const config = require('../configs/config.json');
const pr = new JsonDatabase({ databasePath: './json/userperms.json' });
// Objeto para armazenar os registros de cooldown
const cooldowns = {};

module.exports = {
  name: 'gerar',
  aliases: ['gen'],
  run: async (client, message, args) => {
    const conta = args[0];
    const usuario = message.author.id;

    ////ifs/////
    if (conta !== `${db.get(`${conta}.idserviçe`)}`) return message.reply(`${mj.get("errado")} | ops..parece que esse serviço não existe!!`);
    if (usuario !== `${pr.get(`${usuario}_id`)}`) {
      return message.reply(`${mj.get("errado")} | Ops... parece que você não tem permissão!!`);
    } else {
      // Continue com o restante do código
    }

    const requiredRoleId = config.role; // Especifique o ID da função requerida aqui
    const requiredRole = message.guild.roles.cache.get(requiredRoleId);

    if (!requiredRole || !message.member.roles.cache.has(requiredRole.id)) {
      return message.reply(`${mj.get("errado")} **Olá, você não tem permissão para executar esse comando.**`);
    } else {
      // Continue com o restante do código
    }

    const quantidade = db.get(`${conta}.conta`).length;
    if (quantidade < 1) return message.reply(`${mj.get("errado")} **Olá, este produto está sem stock no momento, não se preocupe, nosso stock já será atualizado novamente.**`);

    // Restante do código aqui...

    // Verificar o tempo desde o último uso do comando
    const cooldownTime = 30; // Tempo em segundos
    const lastUsage = cooldowns[message.author.id] || 0;
    const elapsedTime = Math.floor((Date.now() - lastUsage) / 1000); // Converter para segundos

    if (elapsedTime < cooldownTime) {
      const remainingTime = cooldownTime - elapsedTime;
      return message.reply(`${mj.get("errado")} **Olá, espere mais ${remainingTime} segundos para gerar outra conta.**`);
    }

    // Restante do código...
  }
};
