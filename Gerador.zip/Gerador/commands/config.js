const Discord = require(`discord.js`)
const { JsonDatabase, } = require(`wio.db`);
const perms = new JsonDatabase({ databasePath:`./json/perms.json` });
const db = new JsonDatabase({ databasePath:`./db/products.json` });
const mj = new JsonDatabase({ databasePath:`./configs/emojis.json` });
const fs = require("fs")
const config = require(`../configs/config.json`)
module.exports = {
    name: `config`, 
    run: async(client, message, args,) => {
        const conta = args[0]
const usuario = message.author.id
     ////////ifs/////////
      if (usuario !== `${perms.get(`${usuario}_id`)}`) return message.reply(`${mj.get(`errado`)} **Olá, você não tem permissão para executar esse comando.**`)
      if(db.all().length == 0) return message.reply(`${mj.get(`errado`)} **Olá, vc não tem nenhuma serviço criado no momento.`)
      if (!conta) return message.reply(`${mj.get(`errado`)} **Olá, Coloque o id do serviço.**`)
      
      ///////ifs//////////////
        
      
      const adb = args[0];
      const row = new Discord.MessageActionRow()
        .addComponents(
          new Discord.MessageButton()
            .setCustomId(`nomegerenciar`)
            .setLabel(`Nome serviço`)
            .setEmoji(mj.get(`config`))
            .setStyle(`SECONDARY`)
        )
     
        
        .addComponents(
          new Discord.MessageButton()
            .setCustomId(`bannergerenciar`)
            .setLabel(`Bannner serviço`)
            .setEmoji(mj.get(`config`))
            .setStyle(`SECONDARY`)
        )
        .addComponents(
          new Discord.MessageButton()
            .setCustomId(`footergerenciar`)
            .setLabel(`Rodapé serviço`)
            .setEmoji(mj.get(`config`))
            .setStyle(`SECONDARY`)
        )
         .addComponents(
          new Discord.MessageButton()
            .setCustomId(`estoqueconfig`)
            .setLabel(`Estoque`)
            .setEmoji(mj.get(`config`))
            .setStyle(`SECONDARY`)
        );
          
        
        const embed = await message.channel.send({
          embeds: [
            new Discord.MessageEmbed()

              .setDescription(`
<:Atendente:1135729208992211005> **| Configure o serviço** ${conta}
<:User:1135729214872629409> **| Nome:** ${db.get(`${conta}.nome`)}
<:Carteira:1128880854429597806> **| stock:** ${db.get(`${conta}.conta`).length} ` )
              .setColor(`${config.cor}`),
          ],
         components: [row],
        });
        const interação = embed.createMessageComponentCollector({ componentType: `BUTTON`, })
        interação.on(`collect`, async (interaction) => {
         if (message.author.id != interaction.user.id) {
          return;
         }

         if (interaction.customId === `nomegerenciar`) {
          interaction.deferUpdate();
            message.channel.send(`${mj.get(`carregando`)} | Qual é o novo nome?`).then(msg => {
                const filter = m => m.author.id === interaction.user.id;
                const collector = msg.channel.createMessageCollector({ filter, max: 1 });
                collector.on(`collect`, message => {
                    db.set(`${adb}.nome`, [`${message.content}`])
                    message.delete()
                    msg.delete()
                    message.channel.send(`${mj.get(`correto`)} | nome alterado com sucesso!!`)
  const embednew = new Discord.MessageEmbed()
    .setDescription(`
<:Atendente:1135729208992211005> | Configure o serviço: ${conta}
<:User:1135729214872629409> | Nome: ${db.get(`${conta}.nome`)}
<:Carteira:1128880854429597806> | stock: ${db.get(`${args[0]}.conta`).length} ` )
    .setColor(`${config.cor}`);
                         embed.edit({ embeds: [embednew],components: [row]})
                })
            
                })
            
        }
  




       
         if (interaction.customId === `estoqueconfig`) {
          interaction.deferUpdate();
          const estoque = new Discord.MessageActionRow()
      .addComponents(
        new Discord.MessageButton()
          .setCustomId(`addestoque`)
          .setLabel(`Adicionar`)
          .setEmoji(mj.get(`config`))
          .setStyle(`SECONDARY`)
      )
      .addComponents(
        new Discord.MessageButton()
          .setCustomId(`clestoque`)
          .setLabel(`Limpar`)
          .setEmoji(mj.get(`config`))
          .setStyle(`SECONDARY`)
      )
      .addComponents(
        new Discord.MessageButton()
          .setCustomId(`backup`)
          .setLabel(`Backup`)
          .setEmoji(mj.get(`config`))
          .setStyle(`SECONDARY`)
      )
   
      ;

 const embednew = new Discord.MessageEmbed()
 .setDescription(`
 <:Atendente:1135729208992211005> | Configure o serviço: ${conta}
 <:User:1135729214872629409> | Nome: ${db.get(`${conta}.nome`)}
 <:Carteira:1128880854429597806> | stock: ${db.get(`${args[0]}.conta`).length} ` )
                       .setColor(`${config.cor}`);
                     embed.edit({ embeds: [embednew], components: [estoque] });
         }
          if (interaction.customId === `backup`) {
  interaction.deferUpdate();
  const contas = db.get(`${adb}.conta`);
  if (!contas) {
    message.channel.send(`${mj.get("errado")} | Nenhuma conta encontrada.`);
    return;
  }

  const backup = contas.join(`\n`);

  try {
    fs.writeFileSync(`contas.txt`, backup);
    message.author.send({
      files: [`contas.txt`]
    });
  } catch (error) {
    console.error(error);
    message.channel.send(`${mj.get("errado")} | Ocorreu um erro ao criar o arquivo.`);
  }}

        if (interaction.customId === `clestoque`) {
          interaction.deferUpdate();
          const a = db.get(`${adb}.conta`);
          const removed = a.splice(0, `${db.get(`${adb}.conta`).length}`);
          db.set(`${adb}.conta`, a);
          message.channel.send(
            `${mj.get("correto")} | Estoque limpo!`
          );
        }
         if (interaction.customId === `atualizar`) {
  interaction.deferUpdate();
  const canalEditar = db.get(`${args[0]}.canal`);
  const messageId = db.get(`${args[0]}.message`);
  const cleanMessageId = messageId.replace(`}`, ``); // Remover o caractere '}' extra
  const canal = interaction.guild.channels.cache.get(canalEditar); // Obter o canal pelo ID

  if (canal && canal.isText()) {
    const produto = await canal.messages.fetch(cleanMessageId);
    if (produto) {
      const embedatualizar = new Discord.MessageEmbed()
         .setTitle(`Bot Store | ${client.user.username}`)
          .setDescription(
            `
\`\`\`${db.get(`${args[0]}.conta`).length}\`\`\`
**
✨ | Nome: __${db.get(`${args[0]}.nome`)}__
💳 | Preço: __${db.get(`${args[0]}.preco`)}__
🛒 | Estoque: __${db.get(`${args[0]}.conta`).length}__**
`
          )
          .setThumbnail(client.user.displayAvatarURL())
          .setColor(`${config.cor}`)

      produto.edit({ embeds: [embedatualizar] }); // Atualizar a mensagem com o novo embed
      interaction.channel.send(`${mj.get("correto")} | Produto atualizado com sucesso!`);
    } else {
      interaction.channel.send(`${mj.get("errado")} | Produto não encontrado.`);
    }
  } else {
    interaction.channel.send(`${mj.get("errado")} | Canal do produto não encontrado.`);
  }
}
 if (interaction.customId === `addestoque`) {
         interaction.deferUpdate();
        message.channel.send(`✨  | Mande os novos produtos no chat!`).then(msg => {
          const filter = m => m.author.id === interaction.user.id;
          const collector = msg.channel.createMessageCollector({ filter })
          collector.on(`collect`, message => {
             const content = message.content.split('\n');
             const contasnb = message.content.split('\n').length;
             var contas = content;
             var etapa = 0;
             var etapaf = contasnb;
             collector.stop();
             message.delete()
             const timer = setInterval(async function() {
             if(etapa === etapaf) {
              msg.edit(`${mj.get("correto")} | Foram adicionados \`${etapaf}\`\ produto com sucesso!`)
              clearInterval(timer)
              return;
             }
             const enviando = contas[etapa];
             db.push(`${adb}.conta`, `${enviando}`)
             etapa = etapa + 1
           }, 100)   
        })
    
     
})
 }
    
         if (interaction.customId === `bannergerenciar`) {
           interaction.deferUpdate();
           message.channel.send(`${mj.get("carregando")} | Qual é o novo banner?`).then((msg) => {
             const filter = (m) => m.author.id === interaction.user.id;
             const collector = msg.channel.createMessageCollector({
               filter,
               max: 1,
             });
             collector.on(`collect`, (message) => {
               message.delete();
               msg.edit(`${mj.get("correto")} | Banner Alterado!`);
               const newPrice = message.content;
               const attachment = message.attachments.first();
               if (attachment && attachment.url) {
                 const newBannerUrl = attachment.url;
                 db.set(`${adb}.banner`, newBannerUrl);
                 // Salvar o URL do banner na base de dados

                 const embednew = new Discord.MessageEmbed()
                   .setDescription(
                     `
✨ | Configure o produto ${args[0]}
⛩️ | Nome: ${db.get(`${args[0]}.nome`)}
💳 | Preço: ${newPrice}
💱 | Descrição: ${db.get(`${args[0]}.conta`).length}
`
                   )
                   .setColor(`${config.cor}`);
                 embed.edit({ embeds: [embednew],components: [row] });
               } else {
                 msg.edit(`${mj.get("errado")} | Nenhuma imagem anexada foi encontrada.`);
               }
             });
           });
         }


       

        if (interaction.customId === `estoquegerenciar`) {
            msg.delete()
            const itens = db.get(`${adb}.conta`);
            const row2 = new Discord.MessageActionRow()
                .addComponents(
                    new Discord.MessageButton()
                        .setCustomId('adicionarest')
                        .setEmoji(`<:Correto:1123834022733299732>`)
                        .setLabel('ADICIONAR')
                        .setStyle(`SECONDARY`),
                )
                .addComponents(
                    new Discord.MessageButton()
                        .setCustomId('removerest')
                        .setEmoji(`<:Incorreto:1123833963279028344>`)
                        .setLabel('REMOVER')
                        .setStyle('SECONDARY'),
                );

            const embedest = new Discord.MessageEmbed()
                .setTitle(`${dbB.get(`nomebot`)} | Gerenciar Produto`)
                .setDescription(`Este é seu estoque: \`\`\`${itens.join(` \n`) || `Sem estoque, adicione`}\`\`\``)
                .setColor(`${config.cor}`)
            interaction.channel.send({ embeds: [embedest], components: [row2] }).then(msg => {
                const filter = i => i.user.id === interaction.user.id;
                const collector = msg.createMessageComponentCollector({ filter });
                collector.on(`collect`, interaction => {
                
 

    
                    if (interaction.customId === `removerest`) {
                        const embedest = new Discord.MessageEmbed()
                            .setTitle(`${dbB.get(`nomebot`)} | Gerenciar Produto`)
                            .setDescription(`Este é seu estoque: \`\`\`${itens.join(` \n`) || `Sem estoque`}\`\`\`\n**Para remover um item você irá enviar a linha do produto!**`)
                            .setColor(`${config.cor}`)
                        msg.edit({ embeds: [embedest], components: [] }).then(msg => {
                            const filter = m => m.author.id === interaction.user.id;
                            const collector = msg.channel.createMessageCollector({ filter, max: 1 })
                            collector.on(`collect`, message1 => {
                                const a = db.get(`${adb}.conta`);
                                a.splice(message1.content, 1)
                                db.set(`${adb}.conta`, a);
                                const itens2 = db.get(`${adb}.conta`);
                                const embedest2 = new Discord.MessageEmbed()
                                    .setTitle(`${dbB.get(`nomebot`)} | Gerenciar Produto`)
                                    .setDescription(`Este é seu novo estoque: \`\`\`${itens2.join(` \n`) || `Sem estoque`}\`\`\``)
                                    .setColor(`${config.cor}`)
                                msg.channel.send({ embeds: [embedest2] })
                                const row = new Discord.MessageActionRow()
                                    .addComponents(
                                        new Discord.MessageSelectMenu()
                                            .setCustomId('gerenciar')
                                            .setPlaceholder('Selecione uma opção')
                                            .addOptions(db.all().map(item => ({ label: `ID: ${item.ID} - PREÇO: R$${item.data.preco}`, description: `NOME: ${item.data.nome || `Sem nome`}`, value: item.ID }))),
                                    );
                            })
                        })
                    }
                })
            })
        }
    



           })
         }
       }
