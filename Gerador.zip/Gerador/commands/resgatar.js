const Discord = require("discord.js")
const { JsonDatabase, } = require("wio.db");
const perm = new JsonDatabase({ databasePath:"./json/perms.json" });
const db = new JsonDatabase({ databasePath:"./db/products.json" });
const mj = new JsonDatabase({ databasePath:"./configs/emojis.json" });
const config = require("../configs/config.json")
const kew = new JsonDatabase({ databasePath:"./json/keys.json" });
const pr = new JsonDatabase({ databasePath:"./json/userperms.json" });
module.exports = {
    name: "resgatar", 
    run: async(client, message, args) => {
const key = args[0]
const usuario = message.author.id
if (key !== `${kew.get(`${key}.key`)}`) return message.reply(`${mj.get("errado")} **Olá, essa key esta invalido ou já expiro.**`)
if("true" === `${kew.get(`${key}.resgatado`)}`) return message.reply(`${mj.get("errado")} **Olá, essa key já foi resgatada por algum usúario.**`)
     message.reply(`${mj.get("correto")} **Olá, sua key foi resgatada com sucesso e já esta pronto para usar nosso gerador!**`)
   kew.set(`${key}.resgatado`,`true`)
   pr.set(`${usuario}_id`, `${usuario}`)
       }
     }
